package chat.tox.antox.utils

object Location {
  final val Origin = Location(0, 0)
}

case class Location(x: Int, y: Int)
