package chat.tox.antox.utils

object StorageType extends Enumeration {
  type StorageType = Value
  val NONE, INTERNAL, EXTERNAL = Value
}