package chat.tox.antox.wrapper

class FriendRequest(val requestKey: FriendKey, val requestMessage: String)
