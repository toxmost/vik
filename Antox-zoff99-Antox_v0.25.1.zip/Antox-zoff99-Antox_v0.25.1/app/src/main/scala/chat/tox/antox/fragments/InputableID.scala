package chat.tox.antox.fragments

trait InputableID {
  def inputID(input: String): Unit
}