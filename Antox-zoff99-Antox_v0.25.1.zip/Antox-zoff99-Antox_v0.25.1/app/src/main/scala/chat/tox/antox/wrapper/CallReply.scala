package chat.tox.antox.wrapper

final case class CallReply(id: Int, reply: String)
