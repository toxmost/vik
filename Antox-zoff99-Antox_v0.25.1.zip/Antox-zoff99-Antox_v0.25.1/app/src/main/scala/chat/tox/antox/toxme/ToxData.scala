package chat.tox.antox.toxme

import chat.tox.antox.wrapper.ToxAddress

class ToxData {
  var fileBytes: Array[Byte] = _
  var address: ToxAddress = _
}