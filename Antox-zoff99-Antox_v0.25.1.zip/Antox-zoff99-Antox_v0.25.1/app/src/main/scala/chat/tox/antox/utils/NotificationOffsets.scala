package chat.tox.antox.utils

// contact notification id offsets
object NotificationOffsets {

  val NOTIFICATION_OFFSET_BASE = 0
  val NOTIFICATION_OFFSET_ONGOING_CALL = 1
  val NOTIFICATION_OFFSET_MISSED_CALL = 2
}
