package chat.tox.antox.exceptions

case class AvDeviceNotFoundException(message: String) extends Exception